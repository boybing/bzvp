#!/bin/bash

python3 crt.py