
import os
from datetime import datetime

now = datetime.now().strftime("%Y%m%d%H%M%S")

if not os.path.exists("frpc.toml"):
    print("请选择协议类型：")
    print("1. TCP协议")
    print("2. QUIC协议")
    protocol_choice = input("请输入选项（1或2）：")
    port = input("请输入端口号：")
    
    if protocol_choice == "1":
        # TCP协议配置
        link_str = f'''
serverAddr = "nw.bingzai666.top"
serverPort = 7000

[auth]
method = "token"
token = "bz468255"

[[proxies]]
name = "newyork{now}"
type = "tcp"
localIP = "127.0.0.1"
localPort = 8080
remotePort = {port}

[proxies.transport]
useCompression = true
useEncryption = true
'''
    elif protocol_choice == "2":
        # QUIC协议配置
        link_str = f'''
serverAddr = "nw.bingzai666.top"
serverPort = 7000

[auth]
method = "token"
token = "bz468255"

[transport]
protocol = "quic"

[[proxies]]
name = "newyork{now}"
type = "tcp"
localIP = "127.0.0.1"
localPort = 8080
remotePort = {port}

[proxies.transport]
useCompression = true
useEncryption = true
'''
    else:
        print("无效的选项，默认使用TCP协议")
        link_str = f'''
serverAddr = "nw.bingzai666.top"
serverPort = 7000

[auth]
method = "token"
token = "bz468255"

[[proxies]]
name = "newyork{now}"
type = "tcp"
localIP = "127.0.0.1"
localPort = 8080
remotePort = {port}

[proxies.transport]
useCompression = true
useEncryption = true
'''
    
    with open("frpc.toml", "w") as f:
        f.write(link_str)
    print(f"配置文件 frpc.toml 已生成，使用协议：{'TCP' if protocol_choice == '1' else 'QUIC' if protocol_choice == '2' else 'TCP(默认)'}")
else:
    print("frpc.toml文件已存在")







