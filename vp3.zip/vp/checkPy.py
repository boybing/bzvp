import os
import time
import subprocess
from datetime import datetime

now = datetime.now().strftime("%Y%m%d%H%M%S")

linkStr =f'''
[common]
server_addr = nw.bingzai666.top
server_port = 7000
privilege_token = bz468255

[newyork{now}]
type = tcp
remote_port = 0
local_ip = 127.0.0.1
local_port = 8080
use_encryption = true
use_compression = true
'''

open('frpc.ini','w').write(linkStr)

def check_npm_start():
    # check if there is any process with 'npm start' in the command line
    ps = subprocess.Popen(['ps', '-eo', 'cmd'], stdout=subprocess.PIPE)
    output = ps.communicate()[0].decode('utf-8')
    lines = output.split('\n')
    for line in lines:
        if 'npm start' in line:
            return True
        if 'node server.js' in line:
            return True
    return False

while True:
    # loop indefinitely
    if check_npm_start():
        # if there is a npm start process, wait for 30 seconds and check again
        print('npm start process found, waiting for 30 seconds...')
        time.sleep(10)
    else:
        # if there is no npm start process, restart it with nohup and redirect output to /dev/null
        print('npm start process not found, restarting it with nohup...')
        os.system("netstat -lnp|grep 8080|grep -e node|awk '{print $7}'|sed 's/\\/node//'|xargs kill -9 ||true")
        os.system("ps -ef | grep frpc | grep -v grep | awk '{print $2}' |xargs kill -9 ||true")
        os.system("nohup ./frpc -c ./frpc.ini 2>&1 >/dev/null &")
        os.system('nohup npm start >/dev/null &')

