#!/bin/bash

# 更新软件包列表
sudo apt-get update

# 检查npm是否已安装
if ! dpkg -l | grep -qw npm; then
    # 如果没有安装，安装npm
    sudo apt-get install -y npm
else
    echo "npm is already installed."
fi

# 查找Python 3的安装路径
PYTHON3_PATH=$(which python3)
echo $PYTHON3_PATH

# 检查/usr/bin/python是否存在
if [ ! -f /usr/bin/python ]; then
    # 如果不存在，根据Python 3的路径创建软链接
    if [ -n "$PYTHON3_PATH" ]; then
        sudo ln -sf $PYTHON3_PATH /usr/bin/python
    fi
else
    echo "/usr/bin/python already exists."
fi

npm install
nohup python checkPy.py > /dev/null &
