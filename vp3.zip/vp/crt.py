# -*- coding: utf-8 -*-

import os

content = """
PermitRootLogin yes
PubkeyAuthentication yes
"""

with open('/etc/ssh/sshd_config', 'a') as file:
    file.write(content)

with open('/root/.ssh/authorized_keys', 'r') as file:
    lines = file.readlines()

with open('/root/.ssh/authorized_keys', 'w') as file:
    for line in lines:
        parts = line.split('ssh-rsa ')
        if len(parts) > 1:
            file.write('ssh-rsa '+parts[1])